<template>
    <section class="main-part">
        <img src="../assets/404.png" alt="">
        <!-- <p>Pagina nao encontrada</p> -->
    </section>
</template>


<style scoped>

    .main-part{
        display: flex;
        flex-direction: column;
        padding-top: 5em;
        gap: 2em;
        align-items: center;
    }
        .main-part img{
            width: 20em;
        }

</style>