<script >
    
    export default {
        name: 'AsideNavBar',
        data(){
            return{
                role: {},
                user: {}
            }
        },
        created(){
            // try {
            //     this.role = JSON.parse(localStorage.getItem('role'))
            //     this.user = JSON.parse(localStorage.getItem('userData'))
            // } catch (error) {
            //     console.log(error)
            // }
            // console.log(this.role);
        },
        mounted(){
            try {
                this.role = JSON.parse(localStorage.getItem('role'))
                this.user = JSON.parse(localStorage.getItem('userData'))
            } catch (error) {
                console.log(error)
            }
            console.log(this.role);
        }
    }
    

</script>


<template lang="pt-pt">
    <aside class="shadow">
            <nav>
                <header class="profile">
                    <h1 style="text-wrap:nowrap; font-family: 'arial'">D'Bella Beautty</h1>
                </header>
                <ul>
                    <li>
                        <RouterLink active-class="rota-ativo" id="dash" to="/"> 
                            <span class="icon-text-container">
                                <Icon class="icon" icon="iconamoon:home-fill" /> 
                                <span >Dashboard</span>
                            </span> 
                        </RouterLink>
                        <span class="info"></span>
                    </li>
                    
                    <li v-if="role?.utilizador">
                        <RouterLink active-class="rota-ativo" to="/utilizador">
                            <span class="icon-text-container">
                                <Icon class="icon" icon="mdi:shield-user" /> 
                                <span >utilizadores</span>
                            </span> 
                        </RouterLink>
                        <span class="info"></span>
                    </li>
                    <li v-if="role?.funcionario">
                        <RouterLink active-class="rota-ativo" to="/funcionario">
                            <span class="icon-text-container">
                                <Icon class="icon" icon="clarity:employee-group-solid" /> 
                                <span >Funcionarios</span>
                            </span> 
                        </RouterLink>
                        <span class="info"></span>
                    </li>
                    <li v-if="role?.cliente">
                        <RouterLink active-class="rota-ativo" to="/cliente">
                            <span class="icon-text-container">
                                <Icon icon="ri:contacts-fill" />
                                 
                                <span >Clientes</span>
                            </span> 
                        </RouterLink>
                        <span class="info"></span>
                    </li>
                    <li>
                        <RouterLink active-class="rota-ativo" to="/galeria">
                            <span class="icon-text-container">
                                <Icon class="icon" icon="et:pictures" /> 
                                <span >Galeria</span>
                            </span> 
                        </RouterLink>
                        <span class="info"></span>
                    </li>
                    <li>
                        <RouterLink active-class="rota-ativo" to="/produto">
                            <span class="icon-text-container">
                                <Icon class="icon" icon="game-icons:delicate-perfume" /> 
                                <span >Produtos</span>
                            </span> 
                        </RouterLink>
                        <span class="info"></span>
                    </li>
                    <li v-if="role?.financa">
                        <RouterLink active-class="rota-ativo" to="/financa">
                            <span class="icon-text-container">
                                <Icon icon="material-symbols:finance" /> 
                                <span >Finança</span>
                                <span class="info info-new" style="font-size:8pt">Nova</span>
                            </span> 
                        </RouterLink>
                    </li>
                    <li v-if="role?.agendamento">
                        <RouterLink active-class="rota-ativo" to="/agendamento">
                            <span class="icon-text-container">
                                <Icon icon="ic:outline-menu-book" />
                                <span >Agendamentos</span>
                            </span> 
                        </RouterLink>
                        <span class="info"></span>
                    </li>
                </ul>
            </nav>
            <RouterView />
        </aside>

    <!-- <aside class="shadow">
            ...
        </aside> -->
</template>

<style scoped>

    .rota-ativo{
        color: #fff;
        border-bottom: 1px solid red;
        transform: scale(1.09);
        /* background-color: #0003;
        display: flex;
        justify-content: center;
        align-items: center;
        border-radius: .5em; */
    }

    ul li a .icon-text-container{
        display: flex;
        gap: .3em;
        align-items: end;
        height: 2em;
    }
    
    ul li a .icon-text-container > span{
        font-size: 10pt;
    }
    
    ul li a .icon-text-container .icon{
        font-size: 14pt;
    }

</style>