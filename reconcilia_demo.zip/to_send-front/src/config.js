// export const BASE_URL = process.env.VUE_APP_BASE_URL
// export const KEY = process.env.VUE_APP_API_KEY
export const BASE_URL = "http://127.0.0.1:8000/api/v1"
export const KEY = "1234567890"
