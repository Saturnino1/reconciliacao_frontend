from .authViews import *
from .clienteViews import *
from .historicoViews import *
from .roleViews import *
from .utilizadorViews import *
from .permissaoViews import *