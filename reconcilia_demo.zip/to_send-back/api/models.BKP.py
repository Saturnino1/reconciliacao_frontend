from django.db import models
from django.db.models import Sum


# Create your models here.
class Utilizador(models.Model):
    id = models.AutoField(primary_key=True)
    username = models.CharField(max_length=60, unique=True)
    password = models.CharField(max_length=60)
    role_id = models.ForeignKey('Role',related_name='role_id_U' ,on_delete=models.SET_NULL, db_column='role_id',null=True)
    role_name = models.CharField(max_length=60, null=True, blank=True)
    status = models.CharField(default='ativo', max_length=30)
    class Meta:
        db_table = 'utilizador'
        verbose_name = 'Utilizador'
        verbose_name_plural = 'Utilizadores'
    def save(self, *args, **kwargs):
        if self.role_id:
            self.role_name = self.role_id.nome
        else:
            self.role_name = 'guest'
        super().save(*args, **kwargs)


class Role(models.Model):
    id = models.AutoField(primary_key=True)
    nome = models.CharField(max_length=60, unique=True,default='guest')

    utilizador = models.BooleanField(default=False)
    utilizador_r = models.BooleanField(default=False)
    utilizador_c = models.BooleanField(default=False)
    utilizador_u = models.BooleanField(default=False)
    utilizador_d = models.BooleanField(default=False)
    
    cliente = models.BooleanField(default=False)
    cliente_r = models.BooleanField(default=False)
    cliente_c = models.BooleanField(default=False)
    cliente_u = models.BooleanField(default=False)
    cliente_d = models.BooleanField(default=False)
    
    funcionario = models.BooleanField(default=False)
    funcionario_r = models.BooleanField(default=False)
    funcionario_c = models.BooleanField(default=False)
    funcionario_u = models.BooleanField(default=False)
    funcionario_d = models.BooleanField(default=False)
    
    agendamento = models.BooleanField(default=False)
    agendamento_r = models.BooleanField(default=False)
    agendamento_c = models.BooleanField(default=False)
    agendamento_u = models.BooleanField(default=False)
    agendamento_d = models.BooleanField(default=False)
    
    financa = models.BooleanField(default=False)
    financa_r = models.BooleanField(default=False)
    financa_c = models.BooleanField(default=False)
    financa_u = models.BooleanField(default=False)
    financa_d = models.BooleanField(default=False)

    status = models.CharField(default='ativo', max_length=30)
    class Meta:
        db_table = 'role'
        verbose_name = 'Role'
        verbose_name_plural = 'Roles'


class Agendamento(models.Model):
    id = models.AutoField(primary_key=True)
    data = models.DateField(null=True)
    hora = models.TimeField(null=True)
    tipo = models.CharField(max_length=60,default='regular')
    cliente_id = models.ForeignKey('Cliente', related_name='cliente_id_A', on_delete=models.SET_NULL ,db_column='cliente_id',null=True)
    status = models.CharField(default='ativo', max_length=30)
    class Meta:
        db_table = 'agendamento'
        verbose_name = 'Agendamento'
        verbose_name_plural = 'Agendamentos'


class Agendamento_Servico(models.Model):
    id = models.AutoField(primary_key=True)
    agendamento_id = models.ForeignKey('Agendamento', related_name='agendamento_id_A_Ser' , on_delete=models.SET_NULL, db_column='agendamento_id',null=True)
    servico_id = models.ForeignKey('Servico', related_name= 'servico_id_A_Ser', on_delete=models.SET_NULL ,db_column='servico_id',null=True)
    status = models.CharField(default='ativo', max_length=30)
    class Meta:
        db_table = 'agendamento_servico'
        verbose_name = 'Agendamento Servico'
        verbose_name_plural = 'Agendamento Servicos'

class compra(models.Model):
    id = models.AutoField(primary_key=True)
    data = models.DateField(null=True)
    hora = models.TimeField(null=True)
    valor = models.FloatField(null=True, blank=True)
    cliente_id = models.ForeignKey('Cliente', related_name='cliente_id_C', on_delete=models.SET_NULL ,db_column='cliente_id',null=True)
    status = models.CharField(default='ativo', max_length=30)
    class Meta:
        db_table = 'compra'
        verbose_name = 'Compra'
        verbose_name_plural = 'Compras'

class compra_produto(models.Model):
    id = models.AutoField(primary_key=True)
    compra_id = models.ForeignKey('compra', on_delete=models.SET_NULL, related_name='compra_id' ,db_column='compra_id',null=True)
    produto_id = models.ForeignKey('Produto', on_delete=models.SET_NULL, related_name='produto_id' ,db_column='produto_id',null=True)
    status = models.CharField(default='ativo', max_length=30)
    class Meta:
        db_table = 'compra_produto'
        verbose_name = 'Compra Produto'
        verbose_name_plural = 'Compra Produtos'

class Historico(models.Model):
    id = models.AutoField(primary_key=True)
    descricao = models.TextField(null=True, blank=True)
    data = models.DateField(null=True)
    hora = models.TimeField(null=True)
    acao = models.CharField(max_length=60)
    ip = models.CharField(max_length=60, null=True, blank=True)
    utilizador_id = models.ForeignKey('Utilizador', on_delete=models.SET_NULL, related_name='utilizador_id_H' ,db_column='utilizador_id',null=True)
    status = models.CharField(default='ativo', max_length=30)
    class Meta:
        db_table = 'historico'
        verbose_name = 'Historico'
        verbose_name_plural = 'Historicos'

class agendamento_funcionario(models.Model):
    id = models.AutoField(primary_key=True)
    agendamento_id = models.ForeignKey('Agendamento', on_delete=models.SET_NULL, related_name='agendamento_id' ,db_column='agendamento_id',null=True)
    funcionario_id = models.ForeignKey('Funcionario', on_delete=models.SET_NULL, related_name='funcionario_id' ,db_column='funcionario_id',null=True)
    status = models.CharField(default='ativo', max_length=30)
    class Meta:
        db_table = 'agendamento_funcionario'
        verbose_name = 'Agendamento Funcionario'
        verbose_name_plural = 'Agendamento Funcionarios'



class Notificacao(models.Model):
    id = models.AutoField(primary_key=True)
    titulo = models.CharField(max_length=60, default='Sem titulo')
    emissor_id = models.ForeignKey('Utilizador', on_delete=models.SET_NULL, related_name='emissor_id' ,db_column='emissor_id',default=1)
    receptor_id = models.ForeignKey('Utilizador', on_delete=models.SET_NULL, related_name='receptor_id' ,db_column='receptor_id',null=True)
    descricao = models.TextField(null=True, blank=True)
    status = models.CharField(default='ativo', max_length=30)
    class Meta:
        db_table = 'notificacao'
        verbose_name = 'Notificacao'
        verbose_name_plural = 'Notificacoes' 

class Galeria(models.Model):
    id = models.AutoField(primary_key=True)
    titulo = models.CharField(max_length=60, default='Sem titulo')
    descricao = models.TextField(null=True, blank=True)
    status = models.CharField(default='ativo', max_length=30)
    class Meta:
        db_table = 'galeria'
        verbose_name = 'Galeria'
        verbose_name_plural = 'Galerias'

class galeria_foto(models.Model):
    id = models.AutoField(primary_key=True)
    galeria_id = models.ForeignKey('Galeria', on_delete=models.SET_NULL, related_name='galeria_id' ,db_column='galeria_id',null=True)
    foto_id = models.ForeignKey('Foto', on_delete=models.SET_NULL, related_name='foto_id' ,db_column='foto_id',null=True)
    status = models.CharField(default='ativo', max_length=30)
    class Meta:
        db_table = 'galeria_foto'
        verbose_name = 'Galeria Foto'
        verbose_name_plural = 'Galeria Fotos'

class Foto(models.Model):
    id = models.AutoField(primary_key=True)
    path = models.TextField(null=True, blank=True)
    status = models.CharField(default='ativo', max_length=30)
    class Meta:
        db_table = 'foto'
        verbose_name = 'Foto'
        verbose_name_plural = 'Fotos'        


class Servico(models.Model):
    id = models.AutoField(primary_key=True)
    nome = models.CharField(max_length=60)
    descricao = models.TextField(null=True, blank=True)
    valor = models.FloatField(null=True, blank=True)
    status = models.CharField(default='ativo', max_length=30)
    class Meta:
        db_table = 'servico'
        verbose_name = 'Servico'
        verbose_name_plural = 'Servicos'

class tpfuncionario(models.Model):
    id = models.AutoField(primary_key=True)
    nome = models.CharField(max_length=60, unique=True)
    status = models.CharField(default='ativo', max_length=30)
    class Meta:
        db_table = 'tpfuncionario'
        verbose_name = 'Tipo de Funcionario'
        verbose_name_plural = 'Tipos de Funcionarios'

class Produto(models.Model):
    id = models.AutoField(primary_key=True)
    nome = models.CharField(max_length=60)
    descricao = models.TextField(null=True, blank=True)
    valorAntigo = models.FloatField(null=True, blank=True)
    valor = models.FloatField(null=True, blank=True)
    quantidade = models.IntegerField(null=True, blank=True,default=1)
    status = models.CharField(default='ativo', max_length=30)
    class Meta:
        db_table = 'produto'
        verbose_name = 'Produto'
        verbose_name_plural = 'Produtos'
        

class Funcionario(models.Model):
    id = models.AutoField(primary_key=True)
    nome = models.CharField(max_length=60)
    email = models.CharField(max_length=60)
    avatar = models.TextField(null=True, blank=True)
    especialidade = models.CharField(max_length=60, null=True, blank=True)
    telefone = models.CharField(max_length=60, null=True, blank=True)
    endereco = models.CharField(max_length=60, null=True, blank=True)
    utilizador_id = models.ForeignKey('Utilizador', related_name='utilizador_id_F', on_delete=models.SET_NULL ,db_column='utilizador_id',null=True)
    status = models.CharField(default='ativo', max_length=30)
    class Meta:
        db_table = 'funcionario'
        verbose_name = 'Funcionario'
        verbose_name_plural = 'Funcionarios'


class despesa(models.Model):
    id = models.AutoField(primary_key=True)
    nome = models.CharField(max_length=60)
    descricao = models.TextField(null=True, blank=True)
    valor = models.FloatField(null=True, blank=True)
    status = models.CharField(default='ativo', max_length=30)
    class Meta:
        db_table = 'dispesas'
        verbose_name = 'Dispesa'
        verbose_name_plural = 'Dispesas'

class Financa(models.Model):
    id = models.AutoField(primary_key=True)
    saldo = models.FloatField(null=True, blank=True)
    divida = models.FloatField(null=True, blank=True)
    despesatotal = models.FloatField(null=True, blank=True)
    status = models.CharField(default='ativo', max_length=30)
    class Meta:
        db_table = 'financa'
        verbose_name = 'Financa'
        verbose_name_plural = 'Financas'
    def save(self, *args, **kwargs):
        self.despesatotal = despesa.objects.filter(status='ativo').aggregate(Sum('valor'))['valor__sum'] or 0
        super().save(*args, **kwargs)


class tpcliente(models.Model):
    id = models.AutoField(primary_key=True)
    nome = models.CharField(max_length=60, unique=True)
    status = models.CharField(default='ativo', max_length=30)
    class Meta:
        db_table = 'tpcliente'
        verbose_name = 'Tipo de Cliente'
        verbose_name_plural = 'Tipos de Clientes'


class Cliente(models.Model):
    id = models.AutoField(primary_key=True)
    nome = models.CharField(max_length=60)
    foto = models.TextField(null=True, blank=True)
    email = models.CharField(max_length=100, unique=True)
    telefone = models.CharField(max_length=60, null=True, blank=True)
    endereco = models.CharField(max_length=60, null=True, blank=True)
    status = models.CharField(default='ativo', max_length=30)
    class Meta:
        db_table = 'cliente'
        verbose_name = 'Cliente'
        verbose_name_plural = 'Clientes'